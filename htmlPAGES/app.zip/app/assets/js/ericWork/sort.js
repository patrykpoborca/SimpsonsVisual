
// Sorts the given array by alpha
function AlphaSort(theArray) {
	var alphaArray = theArray;
	alphaArray.sort();
	return alphaArray;
}